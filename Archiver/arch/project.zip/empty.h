#include "definesANDstructs.h"

TTree treeEmpty();
THeap heapEmpty();
TVector vectorEmpty();
TBitArray bitArrayEmpty();