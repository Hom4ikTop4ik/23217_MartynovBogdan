#define freeStructsToo 1

void freeTree(TTree* tree);

void freeHeap(THeap* heap);

void freeVector(TVector* vector);

void freeBitArray(TBitArray* bitArray);