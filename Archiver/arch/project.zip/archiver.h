#include "standard.h"

#include "definesANDstructs.h"
#include "decode.h"
#include "encode.h"
#include "empty.h"
#include "helpful.h"

#include "freeEvery.h"